package org.processmining.petrinetsimulator.parameters;

import java.util.Date;

import org.processmining.petrinetsimulator.constants.SettingsConstants;

import cern.jet.random.AbstractContinousDistribution;
import cern.jet.random.Exponential;
import cern.jet.random.engine.DRand;

public class ConceptDriftSettings {

	private int numberOfDrifts;
	private AbstractContinousDistribution durationOfDriftPeriod, durationOfStablePeriod;

	private double samplingProbEvenPeriods, samplingProbOddPeriods;
	private SimulationSettings coreSimulationSettings;

	private String driftType, driftTransitionFunction;

	public ConceptDriftSettings() {
		this(5, new Exponential(1.0 / 864000000.0, new DRand(new Date(System.currentTimeMillis()))), new Exponential(1.0 / 4320000000.0, new DRand(new Date(System.currentTimeMillis()))), 1, 0,
				SettingsConstants.GRADUAL, SettingsConstants.EXPONENTIAL, new SimulationSettings());
		//DRand rand = new DRand(new Date(System.currentTimeMillis()));
	}

	/**
	 * 
	 * @param numberOfDrifts:
	 *            number of drifts (changes in behavior). Gradual/Momentary
	 *            drifts are counted as one, but algorithms will probably detect
	 *            two drift points: when the drift begins and when it ends
	 * 
	 * @param durationOfDriftPeriod:
	 *            Distribution used to generate the duration of the drifting
	 *            period (def 1 day)
	 * 
	 * @param durationOfStablePeriod:
	 *            Distribution used to generate the duration of a stable period
	 *            (with no drifts) (def 6 days)
	 * 
	 * @param samplingProbEvenPeriods:
	 *            probability of sampling from the base petrinet in a stable
	 *            period (even: 0, 2, 4)
	 * 
	 * @param samplingProbOddPeriods:
	 *            probability of sampling from the base petrinet in a stable
	 *            period (odd: 1, 3, 5).
	 * 
	 * @param driftType
	 *            type of drift to be injected: Sudden, Gradual or Momentary
	 *            (Momentary drift is reverted back without a stable period).
	 * 
	 * @param driftTransitionFunction
	 *            The function to estimate the probability distributions of
	 *            sampling from the petrinets during the drift. could be Linear
	 *            or Exponential
	 * 
	 * @param coreSimulationSettings
	 *            Simulation settings that will be used for simulating traces
	 *            from a petrinet.
	 */
	public ConceptDriftSettings(int numberOfDrifts, AbstractContinousDistribution durationOfDriftPeriod,
			AbstractContinousDistribution durationOfStablePeriod, double samplingProb1, double samplingProb2,
			String driftType, String driftTransitionFunction, SimulationSettings coreSimulationSettings) {

		this.numberOfDrifts = numberOfDrifts;
		this.durationOfStablePeriod = durationOfStablePeriod;
		this.durationOfDriftPeriod = durationOfDriftPeriod;
		this.samplingProbEvenPeriods = samplingProb1;
		this.samplingProbOddPeriods = samplingProb2;
		this.coreSimulationSettings = coreSimulationSettings;
		this.driftType = driftType;
		this.driftTransitionFunction = driftTransitionFunction;

	}

	public int getNumberOfDrifts() {
		return numberOfDrifts;
	}

	public AbstractContinousDistribution getDurationOfDriftPeriod() {
		return durationOfDriftPeriod;
	}

	public AbstractContinousDistribution getDurationOfStablePeriod() {
		return durationOfStablePeriod;
	}

	public double getSamplingProbEvenPeriods() {
		return samplingProbEvenPeriods;
	}

	public double getSamplingProbOddPeriods() {
		return samplingProbOddPeriods;
	}

	public SimulationSettings getCoreSimulationSettings() {
		return coreSimulationSettings;
	}

	public String getDriftType() {
		return driftType;
	}

	public String getDriftTransitionFunction() {
		return driftTransitionFunction;
	}

}
