package org.processmining.petrinetsimulator.parameters;

import java.util.Date;

import cern.jet.random.AbstractContinousDistribution;
import cern.jet.random.Exponential;
import cern.jet.random.engine.DRand;

public class SimulationSettings {

	private int numberOfTraces;
	private Date startDate;

	//this is to avoid simulating infinite loops
	private int maxActivitiesPerCase;
	private int startTraceIndex;
	
	private AbstractContinousDistribution caseArrivalDistribution, taskDurationDistribution;

	public SimulationSettings(int startTraceIndex, int numberOfCases, int maxActivitiesPerCase, long startDate,
			AbstractContinousDistribution caseArrivalDistribution,
			AbstractContinousDistribution taskDurationDistribution) {

		this.numberOfTraces = numberOfCases;
		this.maxActivitiesPerCase = maxActivitiesPerCase;
		this.startDate = new Date(startDate);
		this.startTraceIndex = startTraceIndex;

		/**
		 * They should be created like this:
		 * 
		 * RandomEngine engine = new DRand(); Exponential exponential = new
		 * Exponential(10, engine); int poissonObs = exponential.nextInt();
		 */
		this.caseArrivalDistribution = caseArrivalDistribution;
		this.taskDurationDistribution = taskDurationDistribution;

	}

	//default constructor
	public SimulationSettings() {

		this(0, 1000, 100, 0, new Exponential(1.0/3600000.0, new DRand(new Date(System.currentTimeMillis()))), new Exponential(1.0/3600000.0, new DRand(new Date(System.currentTimeMillis()))));
	}

	public Date getStartDate() {
		return startDate;
	}
	
	public int getFirstTraceID() {
		return startTraceIndex;
	}

	public int getNumberOfTraces() {
		return numberOfTraces;
	}

	public int getMaxActivitiesPerCase() {
		return maxActivitiesPerCase;
	}

	public AbstractContinousDistribution getCaseArrivalDistribution() {
		return caseArrivalDistribution;
	}

	public AbstractContinousDistribution getTaskDurationDistribution() {
		return taskDurationDistribution;
	}
}
