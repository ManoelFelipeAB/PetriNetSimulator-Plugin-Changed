package org.processmining.petrinetsimulator.dialogs;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import org.processmining.petrinetsimulator.constants.SettingsConstants;

public class ConceptDriftSettingsDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = -215523134212281310L;

	private JTextField textField_numDrifts, textField_samplingProbEvenPeriods, textField_DDP_field1,
			textField_DSP_field2, textField_DDP_field2, textField_samplingProbOddPeriods, textField_DSP_field1,
			textField_StartTime, textField_TBA_1, textField_TBA_2, textField_TBE_1, textField_TBE_2,
			textField_MaxTraceSize;
	private JComboBox<String> comboBox_TBE_TU, comboBox_TBA_TU, comboBox_TBE, comboBox_TBA, comboBox_TypesOfDrift,
			comboBox_DriftTransitionFunction, comboBox_DSP_distribution, comboBox_DSP_timeUnits,
			comboBox_DDP_distribution, comboBox_DDP_timeUnits;
	private JButton btnOk;

	private JLabel label_tbe_1, label_tba_1, label_tba_2, label_tbe_2, label_DSP_1, label_DSP_2, label_DDP_1,
			label_DDP_2;

	public ConceptDriftSettingsDialog() {
		setTitle("Concept Drift Simulator Settings");
		getContentPane().setLayout(null);
		setSize(new Dimension(775, 510));
		setLocationRelativeTo(null);

		JLabel lblNumberOfDrifts = new JLabel("Number of Drifts:");
		lblNumberOfDrifts.setBounds(12, 16, 103, 16);
		getContentPane().add(lblNumberOfDrifts);

		textField_numDrifts = new JTextField("5");
		textField_numDrifts.setBounds(223, 13, 164, 22);
		textField_numDrifts.setColumns(10);
		getContentPane().add(textField_numDrifts);

		JLabel lblTypeOfDrift = new JLabel("Type of Drift:");
		lblTypeOfDrift.setBounds(12, 45, 103, 16);
		getContentPane().add(lblTypeOfDrift);

		comboBox_TypesOfDrift = new JComboBox<String>(
				SettingsConstants.getDrifts().toArray(new String[SettingsConstants.getDrifts().size()]));
		comboBox_TypesOfDrift.setSelectedIndex(0);
		comboBox_TypesOfDrift.setBounds(223, 42, 164, 22);
		getContentPane().add(comboBox_TypesOfDrift);

		JLabel lblDriftTransitionFunction = new JLabel("Drift Transition Function:");
		lblDriftTransitionFunction.setBounds(12, 74, 153, 16);
		getContentPane().add(lblDriftTransitionFunction);

		comboBox_DriftTransitionFunction = new JComboBox<String>(
				SettingsConstants.getDriftTypes().toArray(new String[SettingsConstants.getDriftTypes().size()]));
		comboBox_DriftTransitionFunction.setSelectedIndex(0);
		comboBox_DriftTransitionFunction.setBounds(223, 71, 258, 22);
		comboBox_DriftTransitionFunction.setSelectedIndex(0);
		getContentPane().add(comboBox_DriftTransitionFunction);

		JLabel lblsamplingProbEven = new JLabel("Probability of Sampling from Base Model in Even Periods:");
		lblsamplingProbEven.setBounds(12, 106, 341, 16);
		getContentPane().add(lblsamplingProbEven);

		textField_samplingProbEvenPeriods = new JTextField("1");
		textField_samplingProbEvenPeriods.setBounds(365, 103, 116, 22);
		textField_samplingProbEvenPeriods.setColumns(10);
		getContentPane().add(textField_samplingProbEvenPeriods);

		JLabel lblProbabilityOfSampling = new JLabel("Probability of Sampling from Base Model in Odd Periods:");
		lblProbabilityOfSampling.setBounds(12, 138, 341, 16);
		getContentPane().add(lblProbabilityOfSampling);

		textField_samplingProbOddPeriods = new JTextField("0");
		textField_samplingProbOddPeriods.setColumns(10);
		textField_samplingProbOddPeriods.setBounds(365, 135, 116, 22);
		getContentPane().add(textField_samplingProbOddPeriods);

		JLabel lblevenAndOdd = new JLabel("(even and odd periods");
		lblevenAndOdd.setBounds(492, 121, 140, 16);
		getContentPane().add(lblevenAndOdd);

		JLabel lblAfterADrift = new JLabel("alternate after a drift)");
		lblAfterADrift.setBounds(502, 138, 140, 16);
		getContentPane().add(lblAfterADrift);

		JLabel lblDurationOfA = new JLabel("Duration of a Stable Period (DSP):");
		lblDurationOfA.setBounds(12, 180, 200, 16);
		getContentPane().add(lblDurationOfA);

		comboBox_DSP_distribution = new JComboBox<String>(
				SettingsConstants.getDistributions().toArray(new String[SettingsConstants.getDistributions().size()]));
		comboBox_DSP_distribution.setSelectedIndex(0);
		comboBox_DSP_distribution.setBounds(223, 174, 164, 22);
		getContentPane().add(comboBox_DSP_distribution);

		label_DSP_1 = new JLabel("Mean");
		label_DSP_1.setFont(new Font("Tahoma", Font.PLAIN, 9));
		label_DSP_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_DSP_1.setBounds(405, 161, 69, 16);
		getContentPane().add(label_DSP_1);

		textField_DSP_field1 = new JTextField("1");
		textField_DSP_field1.setColumns(10);
		textField_DSP_field1.setBounds(405, 174, 69, 22);
		getContentPane().add(textField_DSP_field1);

		label_DSP_2 = new JLabel("");
		label_DSP_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_DSP_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		label_DSP_2.setBounds(483, 161, 69, 16);
		getContentPane().add(label_DSP_2);

		textField_DSP_field2 = new JTextField("");
		textField_DSP_field2.setColumns(10);
		textField_DSP_field2.setBounds(483, 174, 69, 22);
		getContentPane().add(textField_DSP_field2);

		JLabel label_2 = new JLabel("Time unit:");
		label_2.setBounds(577, 177, 69, 16);
		getContentPane().add(label_2);

		comboBox_DSP_timeUnits = new JComboBox<String>(
				SettingsConstants.getTimeUnits().toArray(new String[SettingsConstants.getTimeUnits().size()]));
		comboBox_DSP_timeUnits.setSelectedIndex(4);
		comboBox_DSP_timeUnits.setBounds(642, 174, 103, 22);
		getContentPane().add(comboBox_DSP_timeUnits);

		JLabel lblDurationOfA_1 = new JLabel("Duration of a Drift Period (DDP):");
		lblDurationOfA_1.setBounds(12, 215, 200, 16);
		getContentPane().add(lblDurationOfA_1);

		JLabel lblexceptSuddenDrift = new JLabel("(Except Sudden Drift)");
		lblexceptSuddenDrift.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblexceptSuddenDrift.setBounds(33, 230, 103, 16);
		getContentPane().add(lblexceptSuddenDrift);

		comboBox_DDP_distribution = new JComboBox<String>(
				SettingsConstants.getDistributions().toArray(new String[SettingsConstants.getDistributions().size()]));
		comboBox_DDP_distribution.setSelectedIndex(0);
		comboBox_DDP_distribution.setBounds(223, 209, 164, 22);
		getContentPane().add(comboBox_DDP_distribution);

		label_DDP_1 = new JLabel("Mean");
		label_DDP_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_DDP_1.setFont(new Font("Tahoma", Font.PLAIN, 9));
		label_DDP_1.setBounds(405, 196, 69, 16);
		getContentPane().add(label_DDP_1);

		textField_DDP_field1 = new JTextField("1");
		textField_DDP_field1.setColumns(10);
		textField_DDP_field1.setBounds(405, 209, 69, 22);
		getContentPane().add(textField_DDP_field1);

		label_DDP_2 = new JLabel("");
		label_DDP_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_DDP_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		label_DDP_2.setBounds(486, 195, 69, 16);
		getContentPane().add(label_DDP_2);

		textField_DDP_field2 = new JTextField("");
		textField_DDP_field2.setColumns(10);
		textField_DDP_field2.setBounds(483, 209, 69, 22);
		getContentPane().add(textField_DDP_field2);

		JLabel label_4 = new JLabel("Time unit:");
		label_4.setBounds(577, 212, 69, 16);
		getContentPane().add(label_4);

		comboBox_DDP_timeUnits = new JComboBox<String>(
				SettingsConstants.getTimeUnits().toArray(new String[SettingsConstants.getTimeUnits().size()]));
		comboBox_DDP_timeUnits.setSelectedIndex(4);
		comboBox_DDP_timeUnits.setBounds(642, 209, 103, 22);
		getContentPane().add(comboBox_DDP_timeUnits);

		JLabel lblTimeBetweenCase = new JLabel("Time between Case Arrivals:");
		lblTimeBetweenCase.setBounds(12, 308, 200, 16);
		getContentPane().add(lblTimeBetweenCase);

		JLabel lblSratrDatetime = new JLabel("Start Date/Time:");
		lblSratrDatetime.setBounds(12, 261, 164, 16);
		getContentPane().add(lblSratrDatetime);

		JLabel lblTimeBetweenEvents = new JLabel("Time between Events:");
		lblTimeBetweenEvents.setBounds(12, 344, 140, 16);
		getContentPane().add(lblTimeBetweenEvents);

		textField_StartTime = new JTextField("01/01/2000 00:00:00");
		textField_StartTime.setBounds(223, 255, 163, 22);
		getContentPane().add(textField_StartTime);
		textField_StartTime.setColumns(10);

		comboBox_TBA = new JComboBox<String>(
				SettingsConstants.getDistributions().toArray(new String[SettingsConstants.getDistributions().size()]));
		comboBox_TBA.setBounds(223, 302, 164, 22);
		comboBox_TBA.setSelectedIndex(0);
		getContentPane().add(comboBox_TBA);

		textField_TBA_1 = new JTextField("1");
		textField_TBA_1.setBounds(405, 302, 69, 22);
		getContentPane().add(textField_TBA_1);
		textField_TBA_1.setColumns(10);

		label_tba_1 = new JLabel("Mean");
		label_tba_1.setFont(new Font("Tahoma", Font.PLAIN, 9));
		label_tba_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_tba_1.setBounds(405, 287, 69, 16);
		getContentPane().add(label_tba_1);

		textField_TBA_2 = new JTextField("");
		textField_TBA_2.setColumns(10);
		textField_TBA_2.setBounds(483, 302, 69, 22);
		getContentPane().add(textField_TBA_2);

		comboBox_TBE = new JComboBox<String>(
				SettingsConstants.getDistributions().toArray(new String[SettingsConstants.getDistributions().size()]));
		comboBox_TBE.setBounds(223, 338, 164, 22);
		comboBox_TBE.setSelectedIndex(0);
		getContentPane().add(comboBox_TBE);

		textField_TBE_1 = new JTextField("1");
		textField_TBE_1.setColumns(10);
		textField_TBE_1.setBounds(405, 338, 69, 22);
		getContentPane().add(textField_TBE_1);

		label_tbe_1 = new JLabel("Mean");
		label_tbe_1.setFont(new Font("Tahoma", Font.PLAIN, 9));
		label_tbe_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_tbe_1.setBounds(405, 323, 69, 16);
		getContentPane().add(label_tbe_1);

		textField_TBE_2 = new JTextField("");
		textField_TBE_2.setColumns(10);
		textField_TBE_2.setBounds(483, 338, 69, 22);
		getContentPane().add(textField_TBE_2);

		JLabel lblDdmmyyyyHhmmss = new JLabel("(dd/MM/yyyy HH:mm:ss)");
		lblDdmmyyyyHhmmss.setBounds(404, 258, 153, 16);
		getContentPane().add(lblDdmmyyyyHhmmss);

		btnOk = new JButton("OK");
		btnOk.setBounds(322, 427, 97, 25);
		getContentPane().add(btnOk);

		comboBox_TBA_TU = new JComboBox<String>(
				SettingsConstants.getTimeUnits().toArray(new String[SettingsConstants.getTimeUnits().size()]));
		comboBox_TBA_TU.setBounds(642, 302, 103, 22);
		comboBox_TBA_TU.setSelectedIndex(4);
		getContentPane().add(comboBox_TBA_TU);

		JLabel lblTimeUnit = new JLabel("Time unit:");
		lblTimeUnit.setBounds(577, 305, 69, 16);
		getContentPane().add(lblTimeUnit);

		JLabel label = new JLabel("Time unit:");
		label.setBounds(577, 341, 69, 16);
		getContentPane().add(label);

		comboBox_TBE_TU = new JComboBox<String>(
				SettingsConstants.getTimeUnits().toArray(new String[SettingsConstants.getTimeUnits().size()]));
		comboBox_TBE_TU.setBounds(642, 338, 103, 22);
		comboBox_TBE_TU.setSelectedIndex(3);
		getContentPane().add(comboBox_TBE_TU);

		label_tba_2 = new JLabel("");
		label_tba_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_tba_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		label_tba_2.setBounds(483, 286, 69, 16);
		getContentPane().add(label_tba_2);

		label_tbe_2 = new JLabel("");
		label_tbe_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_tbe_2.setFont(new Font("Tahoma", Font.PLAIN, 9));
		label_tbe_2.setBounds(483, 322, 69, 16);
		getContentPane().add(label_tbe_2);

		JLabel lblMaxSizeOf = new JLabel("Max Size of a Trace:");
		lblMaxSizeOf.setBounds(12, 390, 164, 16);
		getContentPane().add(lblMaxSizeOf);

		textField_MaxTraceSize = new JTextField();
		textField_MaxTraceSize.setText("100");
		textField_MaxTraceSize.setBounds(223, 387, 164, 22);
		getContentPane().add(textField_MaxTraceSize);
		textField_MaxTraceSize.setColumns(10);

	}

	//listeners
	public void addButtonListener(ActionListener actionListener) {
		btnOk.addActionListener(actionListener);
	}

	public void addDSPComboBoxListener(ActionListener actionListener) {
		comboBox_DSP_distribution.addActionListener(actionListener);
	}

	public void addDDPComboBoxListener(ActionListener actionListener) {
		comboBox_DDP_distribution.addActionListener(actionListener);
	}

	public void addTBAComboBoxListener(ActionListener actionListener) {
		comboBox_TBA.addActionListener(actionListener);
	}

	public void addTBEComboBoxListener(ActionListener actionListener) {
		comboBox_TBE.addActionListener(actionListener);
	}

	//setters
	public void setLabel_DSP_1(String text) {
		label_DSP_1.setText(text);
	}

	public void setLabel_DSP_2(String text) {
		label_DSP_2.setText(text);
	}

	public void setLabel_DDP_1(String text) {
		label_DDP_1.setText(text);
	}

	public void setLabel_DDP_2(String text) {
		label_DDP_2.setText(text);
	}

	public void setLabel_TBA_1(String text) {
		label_tba_1.setText(text);
	}

	public void setLabel_TBA_2(String text) {
		label_tba_2.setText(text);
	}

	public void setLabel_TBE_1(String text) {
		label_tbe_1.setText(text);
	}

	public void setLabel_TBE_2(String text) {
		label_tbe_2.setText(text);
	}

	//getters
	public int getNumberOfDrifts() {
		try {
			return Integer.parseInt(textField_numDrifts.getText());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "The number of drifts should be an integer!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return -1;
		}
	}

	public String getTypeOfDrift() {
		return (String) comboBox_TypesOfDrift.getSelectedItem();
	}

	public String getDriftTransitionFunction() {
		return (String) comboBox_DriftTransitionFunction.getSelectedItem();
	}

	public double getSamplingProbEvenPeriods() {
		try {
			double number = Double.parseDouble(textField_samplingProbEvenPeriods.getText());
			if (number < 0 || number > 1)
				throw new Exception();
			else
				return number;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "The even probability should be an double between 0 and 1!",
					"Format Error", JOptionPane.ERROR_MESSAGE);
			return -1.0;
		}
	}

	public double getSamplingProbOddPeriods() {
		try {
			double number = Double.parseDouble(textField_samplingProbOddPeriods.getText());
			if (number < 0 || number > 1)
				throw new Exception();
			else
				return number;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "The odd probability should be an double between 0 and 1!",
					"Format Error", JOptionPane.ERROR_MESSAGE);
			return -1.0;
		}
	}

	public String getDSPDistribution() {
		return (String) comboBox_DSP_distribution.getSelectedItem();
	}

	public double getDSP_Parameter1() {
		try {
			double number = Double.parseDouble(textField_DSP_field1.getText());
			return number;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "The parameter dsp_1 should be an double!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return -1.0;
		}
	}

	public double getDSP_Parameter2() {
		try {
			if (!textField_DSP_field2.getText().isEmpty())
				return Double.parseDouble(textField_DSP_field2.getText());
			else
				return 0;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "The parameter dsp_2 should be an double!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return -1.0;
		}
	}

	public String getDSP_timeUnits() {
		return (String) comboBox_DSP_timeUnits.getSelectedItem();
	}

	public String getDDPDistribution() {
		return (String) comboBox_DDP_distribution.getSelectedItem();
	}

	public double getDDP_Parameter1() {
		try {
			double number = Double.parseDouble(textField_DDP_field1.getText());
			return number;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "The parameter ddp_1 should be an double!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return -1.0;
		}
	}

	public double getDDP_Parameter2() {
		try {
			if (!textField_DDP_field2.getText().isEmpty())
				return Double.parseDouble(textField_DDP_field2.getText());
			return 0;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "The parameter ddp_2 should be an double!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return -1.0;
		}
	}

	public String getDDP_timeUnits() {
		return (String) comboBox_DDP_timeUnits.getSelectedItem();
	}

	public Date getStartDate() {
		SimpleDateFormat parser = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		try {
			return parser.parse(textField_StartTime.getText());
		} catch (ParseException e) {
			JOptionPane.showMessageDialog(this, "The start date format is incorrect!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return null;
		}
	}

	public String getTBADistribution() {
		return (String) comboBox_TBA.getSelectedItem();
	}

	public double getTBA_Label_1() {
		try {
			return Double.parseDouble(textField_TBA_1.getText());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,
					"The first parameter of the Time between Arrivals Distribution should be numerical!",
					"Format Error", JOptionPane.ERROR_MESSAGE);
			return -1;
		}

	}

	public double getTBA_Label_2() {
		try {
			if (!textField_TBA_2.getText().isEmpty())
				return Double.parseDouble(textField_TBA_2.getText());
			else
				return 0;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,
					"The second parameter of the Time between Arrivals Distribution should be numerical!",
					"Format Error", JOptionPane.ERROR_MESSAGE);
			return -1;
		}

	}

	public String getTBATimeUnits() {
		return (String) comboBox_TBA_TU.getSelectedItem();
	}

	public String getTBEDistribution() {
		return (String) comboBox_TBE.getSelectedItem();
	}

	public double getTBE_Label_1() {
		try {
			return Double.parseDouble(textField_TBE_1.getText());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,
					"The first parameter of the Time between Events Distribution should be numerical!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return -1;
		}

	}

	public double getTBE_Label_2() {
		try {
			if (!textField_TBA_2.getText().isEmpty())
				return Double.parseDouble(textField_TBE_1.getText());
			else
				return 0;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,
					"The second parameter of the Time between Events Distribution should be numerical!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return -1;
		}

	}

	public String getTBETimeUnits() {
		return (String) comboBox_TBE_TU.getSelectedItem();
	}

	public int getNumberOfActivities() {
		try {
			return Integer.parseInt(textField_MaxTraceSize.getText());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "The max. number of activities should be an integer!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return 0;
		}
	}

}
