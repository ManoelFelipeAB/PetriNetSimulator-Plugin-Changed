package org.processmining.petrinetsimulator.dialogs;

import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import org.processmining.petrinetsimulator.constants.SettingsConstants;

public class SettingsDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 142025947317556927L;
	private JTextField textField_numCases, textField_MaxAct, textField_StartTime, textField_TBA_1, textField_TBA_2,
			textField_TBE_1, textField_TBE_2;
	private JComboBox<String> comboBox_TBE_TU, comboBox_TBA_TU, comboBox_TBE, comboBox_TBA;
	private JButton btnOk;

	private JLabel label_tbe_1, label_tbe_2, label_tba_1, label_tba_2;

	public SettingsDialog(List<String> distributions) {
		setTitle("Simulator Settings");
		getContentPane().setLayout(null);
		setSize(new Dimension(750, 341));
		setLocationRelativeTo(null);

		JLabel lblNumberOfCases = new JLabel("Number of Cases:");
		lblNumberOfCases.setBounds(12, 16, 103, 16);
		getContentPane().add(lblNumberOfCases);

		JLabel lblMaxNumberOf = new JLabel("Max number of Activities per Case:");
		lblMaxNumberOf.setBounds(12, 56, 200, 16);
		getContentPane().add(lblMaxNumberOf);

		JLabel lblTimeBetweenCase = new JLabel("Time between Case Arrivals:");
		lblTimeBetweenCase.setBounds(12, 153, 200, 16);
		getContentPane().add(lblTimeBetweenCase);

		JLabel lblSratrDatetime = new JLabel("Start Date/Time:");
		lblSratrDatetime.setBounds(12, 103, 164, 16);
		getContentPane().add(lblSratrDatetime);

		JLabel lblTimeBetweenEvents = new JLabel("Time between Events:");
		lblTimeBetweenEvents.setBounds(12, 200, 140, 16);
		getContentPane().add(lblTimeBetweenEvents);

		textField_numCases = new JTextField("100");
		textField_numCases.setBounds(242, 13, 116, 22);
		getContentPane().add(textField_numCases);
		textField_numCases.setColumns(10);

		textField_MaxAct = new JTextField("100");
		textField_MaxAct.setBounds(242, 53, 116, 22);
		getContentPane().add(textField_MaxAct);
		textField_MaxAct.setColumns(10);

		textField_StartTime = new JTextField("01/01/2000 00:00:00");
		textField_StartTime.setBounds(141, 100, 217, 22);
		getContentPane().add(textField_StartTime);
		textField_StartTime.setColumns(10);

		comboBox_TBA = new JComboBox<String>(distributions.toArray(new String[distributions.size()]));
		comboBox_TBA.setBounds(194, 150, 164, 22);
		comboBox_TBA.setSelectedIndex(0);
		getContentPane().add(comboBox_TBA);

		textField_TBA_1 = new JTextField("1");
		textField_TBA_1.setBounds(376, 150, 69, 22);
		getContentPane().add(textField_TBA_1);
		textField_TBA_1.setColumns(10);

		label_tba_1 = new JLabel("Mean");
		label_tba_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_tba_1.setBounds(376, 135, 69, 16);
		getContentPane().add(label_tba_1);

		label_tba_2 = new JLabel("");
		label_tba_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_tba_2.setBounds(454, 135, 69, 16);
		getContentPane().add(label_tba_2);

		textField_TBA_2 = new JTextField("");
		textField_TBA_2.setColumns(10);
		textField_TBA_2.setBounds(454, 150, 69, 22);
		getContentPane().add(textField_TBA_2);

		comboBox_TBE = new JComboBox<String>(distributions.toArray(new String[distributions.size()]));
		comboBox_TBE.setBounds(194, 197, 164, 22);
		comboBox_TBE.setSelectedIndex(0);
		getContentPane().add(comboBox_TBE);

		textField_TBE_1 = new JTextField("1");
		textField_TBE_1.setColumns(10);
		textField_TBE_1.setBounds(376, 197, 69, 22);
		getContentPane().add(textField_TBE_1);

		label_tbe_1 = new JLabel("Mean");
		label_tbe_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_tbe_1.setBounds(376, 182, 69, 16);
		getContentPane().add(label_tbe_1);

		label_tbe_2 = new JLabel("");
		label_tbe_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_tbe_2.setBounds(454, 182, 69, 16);
		getContentPane().add(label_tbe_2);

		textField_TBE_2 = new JTextField("");
		textField_TBE_2.setColumns(10);
		textField_TBE_2.setBounds(454, 197, 69, 22);
		getContentPane().add(textField_TBE_2);

		JLabel lblDdmmyyyyHhmmss = new JLabel("(dd/MM/yyyy HH:mm:ss)");
		lblDdmmyyyyHhmmss.setBounds(376, 103, 153, 16);
		getContentPane().add(lblDdmmyyyyHhmmss);

		btnOk = new JButton("OK");
		btnOk.setBounds(326, 251, 97, 25);
		getContentPane().add(btnOk);

		comboBox_TBA_TU = new JComboBox<String>(
				SettingsConstants.getTimeUnits().toArray(new String[SettingsConstants.getTimeUnits().size()]));
		comboBox_TBA_TU.setBounds(613, 150, 103, 22);
		comboBox_TBA_TU.setSelectedIndex(4);
		getContentPane().add(comboBox_TBA_TU);

		JLabel lblTimeUnit = new JLabel("Time unit:");
		lblTimeUnit.setBounds(548, 153, 69, 16);
		getContentPane().add(lblTimeUnit);

		JLabel label = new JLabel("Time unit:");
		label.setBounds(548, 200, 69, 16);
		getContentPane().add(label);

		comboBox_TBE_TU = new JComboBox<String>(
				SettingsConstants.getTimeUnits().toArray(new String[SettingsConstants.getTimeUnits().size()]));
		comboBox_TBE_TU.setBounds(613, 197, 103, 22);
		comboBox_TBE_TU.setSelectedIndex(3);
		getContentPane().add(comboBox_TBE_TU);
	}

	//listeners
	public void addButtonListener(ActionListener actionListener) {
		btnOk.addActionListener(actionListener);
	}

	public void addTBAComboBoxListener(ActionListener actionListener) {
		comboBox_TBA.addActionListener(actionListener);
	}

	public void addTBEComboBoxListener(ActionListener actionListener) {
		comboBox_TBE.addActionListener(actionListener);
	}

	//setters
	public void setLabel_TBA_1(String text) {
		label_tba_1.setText(text);
	}

	public void setLabel_TBA_2(String text) {
		label_tba_2.setText(text);
	}

	public void setLabel_TBE_1(String text) {
		label_tbe_1.setText(text);
	}

	public void setLabel_TBE_2(String text) {
		label_tbe_2.setText(text);
	}

	//getters 

	public int getNumberOfCases() {
		try {
			return Integer.parseInt(textField_numCases.getText());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "The number of cases should be an integer!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return 0;
		}
	}

	public int getNumberOfActivities() {
		try {
			return Integer.parseInt(textField_MaxAct.getText());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "The max. number of activities should be an integer!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return 0;
		}
	}

	public Date getStartDate() {
		SimpleDateFormat parser = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		try {
			return parser.parse(textField_StartTime.getText());
		} catch (ParseException e) {
			JOptionPane.showMessageDialog(this, "The start date format is incorrect!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return null;
		}
	}

	public String getTBADistribution() {
		return (String) comboBox_TBA.getSelectedItem();
	}

	public double getTBA_Label_1() {
		try {
			return Double.parseDouble(textField_TBA_1.getText());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,
					"The first parameter of the Time between Arrivals Distribution should be numerical!",
					"Format Error", JOptionPane.ERROR_MESSAGE);
			return -1;
		}

	}

	public double getTBA_Label_2() {
		try {
			if (!textField_TBA_2.getText().isEmpty())
				return Double.parseDouble(textField_TBA_2.getText());
			else
				return 0;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,
					"The second parameter of the Time between Arrivals Distribution should be numerical!",
					"Format Error", JOptionPane.ERROR_MESSAGE);
			return -1;
		}

	}

	public String getTBATimeUnits() {
		return (String) comboBox_TBA_TU.getSelectedItem();
	}

	public String getTBEDistribution() {
		return (String) comboBox_TBE.getSelectedItem();
	}

	public double getTBE_Label_1() {
		try {
			return Double.parseDouble(textField_TBE_1.getText());
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,
					"The first parameter of the Time between Events Distribution should be numerical!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return -1;
		}

	}

	public double getTBE_Label_2() {
		try {
			if (!textField_TBA_2.getText().isEmpty())
				return Double.parseDouble(textField_TBE_1.getText());
			else
				return 0;
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this,
					"The second parameter of the Time between Events Distribution should be numerical!", "Format Error",
					JOptionPane.ERROR_MESSAGE);
			return -1;
		}

	}

	public String getTBETimeUnits() {
		return (String) comboBox_TBE_TU.getSelectedItem();
	}

}
