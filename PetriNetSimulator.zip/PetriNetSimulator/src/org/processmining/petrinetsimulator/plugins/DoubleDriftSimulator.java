package org.processmining.petrinetsimulator.plugins;

import java.util.Date;
import java.util.List;

import org.deckfour.xes.factory.XFactory;
import org.deckfour.xes.factory.XFactoryNaiveImpl;
import org.deckfour.xes.model.XLog;
import org.processmining.contexts.uitopia.UIPluginContext;
import org.processmining.contexts.uitopia.annotations.UITopiaVariant;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.framework.plugin.annotations.Plugin;
import org.processmining.framework.plugin.annotations.PluginVariant;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.petrinetsimulator.algorithms.driftsimulator.petrinet.DoubleDriftSimulatorPN;
import org.processmining.petrinetsimulator.controllers.ConformanceSettingsDialogController;
import org.processmining.petrinetsimulator.help.HelpText;
import org.processmining.petrinetsimulator.parameters.ConceptDriftSettings;
import org.processmining.petrinetsimulator.utils.DrawUtils;

@Plugin(name = "Generate Event Log with Double Concept Drift", parameterLabels = { "Base Petri Net",
		"Base Initial Marking", "First Drift Petri Net", "First Drift Initial Marking", "Second Drift Petri Net",
		"Second Drift Initial Marking", "Concept Drift Parameters" }, returnLabels = {
				"Event Log" }, returnTypes = { XLog.class }, help = HelpText.CONCEPT_DRIFT_TEXT)
public class DoubleDriftSimulator {

	@UITopiaVariant(affiliation = "Eindhoven University of Technology", author = "Alfredo Bolt", email = "a.bolt@tue.nl")
	@PluginVariant(variantLabel = "Using UI", requiredParameterLabels = { 0, 1, 2, 3, 4, 5 })
	public XLog runWithUI(UIPluginContext context, Petrinet pn1, Marking m1, Petrinet pn2, Marking m2, Petrinet pn3,
			Marking m3) {
		ConformanceSettingsDialogController controller = new ConformanceSettingsDialogController();
		ConceptDriftSettings settings = controller.getSettingsObject();
		return runWithoutUI_Custom(context, pn1, m1, pn2, m2, pn3, m3, settings, null);
	}

	@PluginVariant(variantLabel = "Without UI, default settings", requiredParameterLabels = { 0, 1, 2, 3, 4, 5 })
	public XLog runWithoutUI_Default(PluginContext context, Petrinet pn1, Marking m1, Petrinet pn2, Marking m2,
			Petrinet pn3, Marking m3) {
		return runWithoutUI_Custom(context, pn1, m1, pn2, m2, pn3, m3, new ConceptDriftSettings(), null);
	}

	@PluginVariant(variantLabel = "Without UI, custom settings", requiredParameterLabels = { 0, 1, 2, 3, 4, 5, 6 })
	public XLog runWithoutUI_Custom(PluginContext context, Petrinet pn1, Marking m1, Petrinet pn2, Marking m2,
			Petrinet pn3, Marking m3, ConceptDriftSettings settings, XFactory factory) {

		if (factory == null)
			factory = new XFactoryNaiveImpl();

		DoubleDriftSimulatorPN cd = new DoubleDriftSimulatorPN(context, factory, settings);
		XLog log = cd.simulateDrift(pn1, m1, pn2, m2, pn3, m3);

		 
		  List<Date> drifts = cd.getDriftPoints();
		  System.out.println(drifts.toString());
		  
		  DrawUtils.printProbabilityHistogram(cd.getTimePoints(), "Time");
		  DrawUtils.printProbabilityHistogram(cd.getTracePoints(), "Trace ID");

		return log;
	}

}
