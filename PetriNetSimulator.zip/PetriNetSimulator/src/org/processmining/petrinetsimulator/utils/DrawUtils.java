package org.processmining.petrinetsimulator.utils;

import java.awt.BasicStroke;
import java.awt.Color;
import java.util.List;

import javax.swing.JDialog;

import org.apache.commons.lang3.tuple.Pair;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class DrawUtils {

	public static void printProbabilityHistogram(List<Pair<Long, Double>> plottingPoints, String variable) {
		// TODO Auto-generated method stub

		JFreeChart xylineChart = ChartFactory.createXYLineChart("Concept drift sampling probabilities", variable,
				"Sampling Probability", createDataset(plottingPoints), PlotOrientation.VERTICAL, true,
				true, false);

		ChartPanel chartPanel = new ChartPanel(xylineChart);
		chartPanel.setPreferredSize(new java.awt.Dimension(560, 367));
		final XYPlot plot = xylineChart.getXYPlot();
		XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
		renderer.setSeriesPaint(0, Color.RED);
		renderer.setSeriesPaint(1, Color.BLUE);

		renderer.setSeriesStroke(0, new BasicStroke(3.0f));
		renderer.setSeriesStroke(1, new BasicStroke(3.0f));

		plot.setRenderer(renderer);

		JDialog dialog = new JDialog();
		dialog.setContentPane(chartPanel);
		dialog.pack();
		dialog.setVisible(true);

	}

	private static XYDataset createDataset(List<Pair<Long, Double>> plottingPoints) {
		// TODO Auto-generated method stub

		final XYSeries baseModel = new XYSeries("Base Model");
		
		final XYSeries driftModel = new XYSeries("Drift Model");
		
		for(Pair<Long,Double> pair : plottingPoints){
			baseModel.add((double)pair.getLeft(), pair.getRight());
			driftModel.add((double)pair.getLeft(), (1.0 - pair.getRight()));
		}

		final XYSeriesCollection dataset = new XYSeriesCollection();
		dataset.addSeries(baseModel);
		dataset.addSeries(driftModel);

		return dataset;
	}

}
