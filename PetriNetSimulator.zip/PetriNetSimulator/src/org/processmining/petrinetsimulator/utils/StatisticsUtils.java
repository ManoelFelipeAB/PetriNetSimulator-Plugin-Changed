package org.processmining.petrinetsimulator.utils;

import org.processmining.petrinetsimulator.constants.SettingsConstants;

import cern.jet.random.AbstractContinousDistribution;
import cern.jet.random.Exponential;
import cern.jet.random.Normal;

public class StatisticsUtils {

	public static double getProbability(long t, long period, double initialProb, double finalProb,
			AbstractContinousDistribution distribution, String driftTransitionFunction) {

		switch (driftTransitionFunction) {
			case SettingsConstants.LINEAR :
				return getLinearProbability(t, period, initialProb, finalProb);
			case SettingsConstants.USEOTHER :
				if (distribution instanceof Exponential)
					return getExponentialProbability(t, period, initialProb, finalProb, (Exponential) distribution);
				else if (distribution instanceof Normal)
					return getNormalProbability(t, period, initialProb, finalProb, (Normal) distribution);
		}
		return -1;
	}

	private static double getLinearProbability(long t, long period, double initialProb, double finalProb) {
		assert t <= period;
		assert initialProb >= 0 && initialProb <= 1 && finalProb >= 0 && finalProb <= 1;

		return initialProb + ((finalProb - initialProb) * t) / period;
	}

	private static double getExponentialProbability(long t, long period, double initialProb, double finalProb,
			Exponential distribution) {
		assert t <= period;
		assert initialProb >= 0 && initialProb <= 1 && finalProb >= 0 && finalProb <= 1;
		assert distribution != null;

		return initialProb + ((finalProb - initialProb) * distribution.cdf(t)) / distribution.cdf(period);
	}

	private static double getNormalProbability(long t, long period, double initialProb, double finalProb,
			Normal distribution) {
		assert t <= period;
		assert initialProb >= 0 && initialProb <= 1 && finalProb >= 0 && finalProb <= 1;
		assert distribution != null;

		return initialProb + ((finalProb - initialProb) * distribution.cdf(t)) / distribution.cdf(period);
	}

}
