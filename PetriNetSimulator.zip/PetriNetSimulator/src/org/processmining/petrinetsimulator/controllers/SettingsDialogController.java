package org.processmining.petrinetsimulator.controllers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import org.processmining.petrinetsimulator.constants.SettingsConstants;
import org.processmining.petrinetsimulator.dialogs.SettingsDialog;
import org.processmining.petrinetsimulator.parameters.SimulationSettings;

import cern.jet.random.AbstractContinousDistribution;
import cern.jet.random.Exponential;
import cern.jet.random.Normal;
import cern.jet.random.Uniform;
import cern.jet.random.engine.DRand;
import cern.jet.random.engine.RandomEngine;

public class SettingsDialogController {

	SettingsDialog dialog;

	public SettingsDialogController() {

		dialog = new SettingsDialog(SettingsConstants.getDistributions());
		dialog.setModal(true);
		dialog.addButtonListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				if (dialog.getNumberOfCases() > 0 && dialog.getNumberOfActivities() > 0 && dialog.getStartDate() != null
						&& dialog.getTBA_Label_1() > -1 && dialog.getTBA_Label_2() > -1 && dialog.getTBE_Label_1() > -1
						&& dialog.getTBE_Label_2() > -1) {
					dialog.dispose();
				}
			}
		});

		dialog.addTBAComboBoxListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				switch (dialog.getTBADistribution()) {
					case SettingsConstants.EXPONENTIAL :
						dialog.setLabel_TBA_1(SettingsConstants.MEAN);
						dialog.setLabel_TBA_2(SettingsConstants.NONE);
						break;
					case SettingsConstants.NORMAL :
						dialog.setLabel_TBA_1(SettingsConstants.MEAN);
						dialog.setLabel_TBA_2(SettingsConstants.STDDEV);
						break;
					case SettingsConstants.UNIFORM :
						dialog.setLabel_TBA_1(SettingsConstants.MIN);
						dialog.setLabel_TBA_2(SettingsConstants.MAX);
						break;
				}
				dialog.doLayout();
				dialog.repaint();
			}
		});

		dialog.addTBEComboBoxListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				switch (dialog.getTBEDistribution()) {
					case SettingsConstants.EXPONENTIAL :
						dialog.setLabel_TBE_1(SettingsConstants.MEAN);
						dialog.setLabel_TBE_2(SettingsConstants.NONE);
						break;
					case SettingsConstants.NORMAL :
						dialog.setLabel_TBE_1(SettingsConstants.MEAN);
						dialog.setLabel_TBE_2(SettingsConstants.STDDEV);
						break;
					case SettingsConstants.UNIFORM :
						dialog.setLabel_TBE_1(SettingsConstants.MIN);
						dialog.setLabel_TBE_2(SettingsConstants.MAX);
						break;
				}
				dialog.doLayout();
				dialog.repaint();

			}

		});
		dialog.setVisible(true);
	}

	public SimulationSettings getSettingsObject() {

		AbstractContinousDistribution tba = null, tbe = null;
		RandomEngine engine = new DRand();

		//everything goes to the miliseconds level

		switch (dialog.getTBADistribution()) {
			case SettingsConstants.EXPONENTIAL :
				tba = new Exponential(1.0 / getTimeInMiliseconds(dialog.getTBA_Label_1(), dialog.getTBATimeUnits()),
						engine);
				break;
			case SettingsConstants.NORMAL :
				tba = new Normal(getTimeInMiliseconds(dialog.getTBA_Label_1(), dialog.getTBATimeUnits()),
						getTimeInMiliseconds(dialog.getTBA_Label_2(), dialog.getTBATimeUnits()), engine);
				break;
			case SettingsConstants.UNIFORM :
				tba = new Uniform(getTimeInMiliseconds(dialog.getTBA_Label_1(), dialog.getTBATimeUnits()),
						getTimeInMiliseconds(dialog.getTBA_Label_2(), dialog.getTBATimeUnits()), engine);
				break;
		}

		switch (dialog.getTBEDistribution()) {
			case SettingsConstants.EXPONENTIAL :
				tbe = new Exponential(1.0 / getTimeInMiliseconds(dialog.getTBE_Label_1(), dialog.getTBETimeUnits()),
						engine);
				break;
			case SettingsConstants.NORMAL :
				tbe = new Normal(getTimeInMiliseconds(dialog.getTBE_Label_1(), dialog.getTBETimeUnits()),
						getTimeInMiliseconds(dialog.getTBE_Label_2(), dialog.getTBETimeUnits()), engine);
				break;
			case SettingsConstants.UNIFORM :
				tbe = new Uniform(getTimeInMiliseconds(dialog.getTBE_Label_1(), dialog.getTBETimeUnits()),
						getTimeInMiliseconds(dialog.getTBE_Label_2(), dialog.getTBETimeUnits()), engine);
				break;
		}

		SimulationSettings settings = new SimulationSettings(0, dialog.getNumberOfCases(),
				dialog.getNumberOfActivities(), dialog.getStartDate().getTime(), tba, tbe);

		return settings;
	}

	private long getTimeInMiliseconds(double input, String timeUnit) {
		switch (timeUnit) {
			case SettingsConstants.SECONDS :
				return Math.round(input * 1000.0);
			case SettingsConstants.MINUTES :
				return Math.round(input * 1000.0 * 60);
			case SettingsConstants.HOURS :
				return Math.round(input * 1000.0 * 60 * 60);
			case SettingsConstants.DAYS :
				return Math.round(input * 1000.0 * 60 * 60 * 24);
			case SettingsConstants.MONTHS :
				return Math.round(input * 1000.0 * 60 * 60 * 24 * 30);
			case SettingsConstants.YEARS :
				return Math.round(input * 1000.0 * 60 * 60 * 24 * 30 * 12);
			default :
				return 0;
		}
	}

}
