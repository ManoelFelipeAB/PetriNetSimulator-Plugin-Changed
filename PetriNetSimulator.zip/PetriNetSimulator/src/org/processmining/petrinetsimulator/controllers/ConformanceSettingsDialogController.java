package org.processmining.petrinetsimulator.controllers;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import org.processmining.petrinetsimulator.constants.SettingsConstants;
import org.processmining.petrinetsimulator.dialogs.ConceptDriftSettingsDialog;
import org.processmining.petrinetsimulator.parameters.ConceptDriftSettings;
import org.processmining.petrinetsimulator.parameters.SimulationSettings;

import cern.jet.random.AbstractContinousDistribution;
import cern.jet.random.Exponential;
import cern.jet.random.Normal;
import cern.jet.random.Uniform;
import cern.jet.random.engine.DRand;
import cern.jet.random.engine.RandomEngine;

public class ConformanceSettingsDialogController {

	ConceptDriftSettingsDialog dialog;

	public ConformanceSettingsDialogController() {

		dialog = new ConceptDriftSettingsDialog();
		dialog.setModal(true);
		dialog.addButtonListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				if (dialog.getNumberOfDrifts() > 0 && dialog.getNumberOfActivities() > 0
						&& dialog.getStartDate() != null && dialog.getTBA_Label_1() > -1 && dialog.getTBA_Label_2() > -1
						&& dialog.getTBE_Label_1() > -1 && dialog.getTBE_Label_2() > -1
						&& dialog.getDSP_Parameter1() > -1 && dialog.getDSP_Parameter2() > -1
						&& dialog.getDDP_Parameter1() > -1 && dialog.getDDP_Parameter2() > -1
						&& dialog.getSamplingProbEvenPeriods() >= 0 && dialog.getSamplingProbEvenPeriods() <= 1
						&& dialog.getSamplingProbOddPeriods() >= 0 && dialog.getSamplingProbOddPeriods() <= 1) {
					dialog.dispose();
				}
			}
		});

		dialog.addTBAComboBoxListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				switch (dialog.getTBADistribution()) {
					case SettingsConstants.EXPONENTIAL :
						dialog.setLabel_TBA_1(SettingsConstants.MEAN);
						dialog.setLabel_TBA_2(SettingsConstants.NONE);
						break;
					case SettingsConstants.NORMAL :
						dialog.setLabel_TBA_1(SettingsConstants.MEAN);
						dialog.setLabel_TBA_2(SettingsConstants.STDDEV);
						break;
					case SettingsConstants.UNIFORM :
						dialog.setLabel_TBA_1(SettingsConstants.MIN);
						dialog.setLabel_TBA_2(SettingsConstants.MAX);
						break;
				}
				dialog.doLayout();
				dialog.repaint();
			}
		});

		dialog.addTBEComboBoxListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				switch (dialog.getTBEDistribution()) {
					case SettingsConstants.EXPONENTIAL :
						dialog.setLabel_TBE_1(SettingsConstants.MEAN);
						dialog.setLabel_TBE_2(SettingsConstants.NONE);
						break;
					case SettingsConstants.NORMAL :
						dialog.setLabel_TBE_1(SettingsConstants.MEAN);
						dialog.setLabel_TBE_2(SettingsConstants.STDDEV);
						break;
					case SettingsConstants.UNIFORM :
						dialog.setLabel_TBE_1(SettingsConstants.MIN);
						dialog.setLabel_TBE_2(SettingsConstants.MAX);
						break;
				}
				dialog.doLayout();
				dialog.repaint();

			}

		});

		dialog.addDSPComboBoxListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				switch (dialog.getDSPDistribution()) {
					case SettingsConstants.EXPONENTIAL :
						dialog.setLabel_DSP_1(SettingsConstants.MEAN);
						dialog.setLabel_DSP_2(SettingsConstants.NONE);
						break;
					case SettingsConstants.NORMAL :
						dialog.setLabel_DSP_1(SettingsConstants.MEAN);
						dialog.setLabel_DSP_2(SettingsConstants.STDDEV);
						break;
					case SettingsConstants.UNIFORM :
						dialog.setLabel_DSP_1(SettingsConstants.MIN);
						dialog.setLabel_DSP_2(SettingsConstants.MAX);
						break;
				}
				dialog.doLayout();
				dialog.repaint();
			}
		});
		dialog.addDDPComboBoxListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				switch (dialog.getDDPDistribution()) {
					case SettingsConstants.EXPONENTIAL :
						dialog.setLabel_DDP_1(SettingsConstants.MEAN);
						dialog.setLabel_DDP_2(SettingsConstants.NONE);
						break;
					case SettingsConstants.NORMAL :
						dialog.setLabel_DDP_1(SettingsConstants.MEAN);
						dialog.setLabel_DDP_2(SettingsConstants.STDDEV);
						break;
					case SettingsConstants.UNIFORM :
						dialog.setLabel_DDP_1(SettingsConstants.MIN);
						dialog.setLabel_DDP_2(SettingsConstants.MAX);
						break;
				}
				dialog.doLayout();
				dialog.repaint();
			}
		});
		dialog.setVisible(true);
	}

	public ConceptDriftSettings getSettingsObject() {

		AbstractContinousDistribution tba = null, tbe = null, dsp = null, ddp = null;
		RandomEngine engine = new DRand(new Date(System.currentTimeMillis()));

		//everything goes to the miliseconds level

		switch (dialog.getTBADistribution()) {
			case SettingsConstants.EXPONENTIAL :
				tba = new Exponential(1.0 / getTimeInMiliseconds(dialog.getTBA_Label_1(), dialog.getTBATimeUnits()),
						engine);
				break;
			case SettingsConstants.NORMAL :
				tba = new Normal(getTimeInMiliseconds(dialog.getTBA_Label_1(), dialog.getTBATimeUnits()),
						getTimeInMiliseconds(dialog.getTBA_Label_2(), dialog.getTBATimeUnits()), engine);
				break;
			case SettingsConstants.UNIFORM :
				tba = new Uniform(getTimeInMiliseconds(dialog.getTBA_Label_1(), dialog.getTBATimeUnits()),
						getTimeInMiliseconds(dialog.getTBA_Label_2(), dialog.getTBATimeUnits()), engine);
				break;
		}

		switch (dialog.getTBEDistribution()) {
			case SettingsConstants.EXPONENTIAL :
				tbe = new Exponential(1.0 / getTimeInMiliseconds(dialog.getTBE_Label_1(), dialog.getTBETimeUnits()),
						engine);
				break;
			case SettingsConstants.NORMAL :
				tbe = new Normal(getTimeInMiliseconds(dialog.getTBE_Label_1(), dialog.getTBETimeUnits()),
						getTimeInMiliseconds(dialog.getTBE_Label_2(), dialog.getTBETimeUnits()), engine);
				break;
			case SettingsConstants.UNIFORM :
				tbe = new Uniform(getTimeInMiliseconds(dialog.getTBE_Label_1(), dialog.getTBETimeUnits()),
						getTimeInMiliseconds(dialog.getTBE_Label_2(), dialog.getTBETimeUnits()), engine);
				break;
		}

		switch (dialog.getDSPDistribution()) {
			case SettingsConstants.EXPONENTIAL :
				dsp = new Exponential(1.0 / getTimeInMiliseconds(dialog.getDSP_Parameter1(), dialog.getDSP_timeUnits()),
						engine);
				break;
			case SettingsConstants.NORMAL :
				dsp = new Normal(getTimeInMiliseconds(dialog.getDSP_Parameter1(), dialog.getDSP_timeUnits()),
						getTimeInMiliseconds(dialog.getDSP_Parameter2(), dialog.getDSP_timeUnits()), engine);
				break;
			case SettingsConstants.UNIFORM :
				dsp = new Uniform(getTimeInMiliseconds(dialog.getDSP_Parameter1(), dialog.getDSP_timeUnits()),
						getTimeInMiliseconds(dialog.getDSP_Parameter2(), dialog.getDSP_timeUnits()), engine);
				break;
		}

		switch (dialog.getDDPDistribution()) {
			case SettingsConstants.EXPONENTIAL :
				ddp = new Exponential(1.0 / getTimeInMiliseconds(dialog.getDDP_Parameter1(), dialog.getDDP_timeUnits()),
						engine);
				break;
			case SettingsConstants.NORMAL :
				ddp = new Normal(getTimeInMiliseconds(dialog.getDDP_Parameter1(), dialog.getDDP_timeUnits()),
						getTimeInMiliseconds(dialog.getDDP_Parameter2(), dialog.getDDP_timeUnits()), engine);
				break;
			case SettingsConstants.UNIFORM :
				ddp = new Uniform(getTimeInMiliseconds(dialog.getDDP_Parameter1(), dialog.getDDP_timeUnits()),
						getTimeInMiliseconds(dialog.getDDP_Parameter2(), dialog.getDDP_timeUnits()), engine);
				break;
		}

		SimulationSettings simuSettings = new SimulationSettings(0, 0, dialog.getNumberOfActivities(),
				dialog.getStartDate().getTime(), tba, tbe);

		return new ConceptDriftSettings(dialog.getNumberOfDrifts(), ddp, dsp, dialog.getSamplingProbEvenPeriods(),
				dialog.getSamplingProbOddPeriods(), dialog.getTypeOfDrift(), dialog.getDriftTransitionFunction(),
				simuSettings);
	}

	private long getTimeInMiliseconds(double input, String timeUnit) {
		switch (timeUnit) {
			case SettingsConstants.MILISECONDS:
				return Math.round(input);
			case SettingsConstants.SECONDS:
				return Math.round(input * 1000.0);
			case SettingsConstants.MINUTES:
				return Math.round(input * 1000.0 * 60);
			case SettingsConstants.HOURS:
				return Math.round(input * 1000.0 * 60 * 60);
			case SettingsConstants.DAYS:
				return Math.round(input * 1000.0 * 60 * 60 * 24);
			case SettingsConstants.MONTHS:
				return Math.round(input * 1000.0 * 60 * 60 * 24 * 30);
			case SettingsConstants.YEARS:
				return Math.round(input * 1000.0 * 60 * 60 * 24 * 30 * 12);
			default:
				return 0;
			}
	}
}
