package org.processmining.petrinetsimulator.constants;

import java.util.ArrayList;
import java.util.List;

public class SettingsConstants {

	public static final String EXPONENTIAL = "Exponential", NORMAL = "Normal", UNIFORM = "Uniform", USEOTHER = "Same as DDP distribution";

	public static final String MIN = "Min", MAX = "Max", MEAN = "Mean", STDDEV = "Std. Dev.", NONE = "(not used)";

	public static final String MILISECONDS = "Miliseconds", SECONDS = "Seconds", MINUTES = "Minutes", HOURS = "Hours",
			DAYS = "days", MONTHS = "Months", YEARS = "Years";

	//for concept drift
	public static final String SUDDEN = "Sudden", GRADUAL = "Gradual", MOMENTARY = "Momentary";
	public static final String LINEAR = "Linear", SLOPE = "Slope";

	public static List<String> getDistributions() {

		List<String> distributions = new ArrayList<String>();
		distributions.add(EXPONENTIAL);
		distributions.add(NORMAL);
		distributions.add(UNIFORM);
		return distributions;
	}

	public static List<String> getDrifts() {

		List<String> drifts = new ArrayList<String>();
		drifts.add(SUDDEN);
		drifts.add(GRADUAL);
		drifts.add(MOMENTARY);
		return drifts;
	}

	public static List<String> getDriftTypes() {

		List<String> drifts = new ArrayList<String>();
		drifts.add(LINEAR);
		drifts.add(USEOTHER);
		return drifts;
	}

	public static List<String> getTimeUnits() {

		List<String> distributions = new ArrayList<String>();
		distributions.add(MILISECONDS);
		distributions.add(SECONDS);
		distributions.add(MINUTES);
		distributions.add(HOURS);
		distributions.add(DAYS);
		distributions.add(MONTHS);
		distributions.add(YEARS);
		return distributions;
	}

	public static String getFirstLabel(String distribution) {
		switch (distribution) {
			case EXPONENTIAL :
			case NORMAL :
				return MEAN;
			case UNIFORM :
				return MIN;
			case LINEAR :
				return SLOPE;
			default :
				return NONE;
		}
	}

	public static String getSecondLabel(String distribution) {
		switch (distribution) {
			case NORMAL :
				return STDDEV;
			case UNIFORM :
				return MAX;
			default :
				return NONE;
		}
	}

}
