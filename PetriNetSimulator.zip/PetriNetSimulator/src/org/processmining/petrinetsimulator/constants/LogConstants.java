package org.processmining.petrinetsimulator.constants;

public class LogConstants {

	public static String TIMESTAMP = "time:timestamp", EVENTID = "concept:name", TRACEID = "concept:name", LIFECYCLE = "lifecycle:transition";

}
