package org.processmining.petrinetsimulator.algorithms.tracesimulator.processtree;

import org.deckfour.xes.factory.XFactory;
import org.deckfour.xes.model.XAttributeMap;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XTrace;
import org.processmining.changepatterns.constants.LogConstants;
import org.processmining.changepatterns.utils.TimeUtils;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.petrinetsimulator.algorithms.tracesimulator.abstr.TraceSimulatorAbstr;
import org.processmining.petrinetsimulator.parameters.SimulationSettings;
import org.processmining.ptandloggenerator.models.NewickTree;
import org.processmining.ptandloggenerator.plugins.GenerateLog;

/**
 * Simulator for Newick Trees
 * 
 * @author abolt
 *
 */
public class TraceSimulatorNT extends TraceSimulatorAbstr {

	private NewickTree tree;

	public TraceSimulatorNT(PluginContext context, NewickTree tree, XFactory factory, SimulationSettings settings) {
		super(context, factory, settings);
		this.tree = tree;
	}

	public XTrace simulateTrace(long startTime, int traceID) {
		/**
		 * Generates a log with one trace.
		 */
		GenerateLog generator = new GenerateLog();
		XTrace trace = generator.run(context, tree, 1).get(0);

		/**
		 * Set trace attributes
		 */
		XAttributeMap atts = factory.createAttributeMap();
		atts.put(LogConstants.TRACEID,
				factory.createAttributeLiteral(LogConstants.TRACEID, Integer.toString(traceID), null));
		trace.setAttributes(atts);

		/**
		 * Add time to all events in the trace according to the specified
		 * distribution
		 */
		long eventTime = startTime;
		for (XEvent e : trace) {
			addTime(e, eventTime);
			eventTime = TimeUtils.getNextTime(eventTime, settings.getTaskDurationDistribution());
		}
		
		System.out.println("trace generated @ " + System.currentTimeMillis());
		return trace;
	}

	private void addTime(XEvent event, long time) {
		XAttributeMap atts = event.getAttributes();
		atts.put(LogConstants.TIMESTAMP, factory.createAttributeTimestamp(LogConstants.TIMESTAMP, time, null));
	}

}
