package org.processmining.petrinetsimulator.algorithms.tracesimulator.petrinet;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.deckfour.xes.factory.XFactory;
import org.deckfour.xes.model.XAttributeMap;
import org.deckfour.xes.model.XTrace;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.graphbased.directed.petrinet.elements.Place;
import org.processmining.models.graphbased.directed.petrinet.elements.Transition;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.petrinetsimulator.algorithms.tracesimulator.abstr.TraceSimulatorAbstr;
import org.processmining.petrinetsimulator.constants.LogConstants;
import org.processmining.petrinetsimulator.parameters.SimulationSettings;
import org.processmining.petrinetsimulator.utils.PetrinetUtils;

import com.google.common.collect.Lists;

/**
 * Simulator for Petri nets.
 * 
 * @author abolt
 *
 */
public class TraceSimulatorPN extends TraceSimulatorAbstr {

	private Petrinet petriNet;
	private Marking initialMarking;

	public TraceSimulatorPN(PluginContext context, Petrinet petriNet, Marking initialMarking, XFactory factory,
			SimulationSettings settings) {

		super(context, factory, settings);

		this.petriNet = petriNet;
		this.initialMarking = initialMarking;
	}

	public XTrace simulateTrace(long startTime, int traceID) {

		XAttributeMap atts = factory.createAttributeMap();
		atts.put(LogConstants.TRACEID,
				factory.createAttributeLiteral(LogConstants.TRACEID, Integer.toString(traceID), null));

		XTrace trace = factory.createTrace(atts);
		long eventTime = startTime;

		//initialize markings
		Map<Place, Integer> markings = new HashMap<Place, Integer>();
		for (Place p : petriNet.getPlaces())
			markings.put(p, 0);

		//update with initial marking
		for (Place p : initialMarking.baseSet())
			markings.put(p, 1);

		//for a given max number of events
		for (int i = 0; i < settings.getMaxActivitiesPerCase(); i++) {

			//detect enabled transitions and fire a random one

			Set<Place> placesWithTokens = new HashSet<Place>();
			for (Place p : markings.keySet())
				if (markings.get(p) > 0)
					placesWithTokens.add(p);

			Set<Transition> nextTransitions = new HashSet<Transition>();
			//first add all
			for (Place p : placesWithTokens) {
				nextTransitions.addAll(PetrinetUtils.getNextTransitions(p, petriNet));
			}
			//now keep only the enabled ones
			Set<Transition> enabledTransitions = new HashSet<Transition>();
			for (Transition t : nextTransitions)
				if (PetrinetUtils.isTransitionEnabled(t, markings, petriNet))
					enabledTransitions.add(t);

			//if there are enabled normal transitions, fire a random one
			//if not, if there are enabled silent transitions, fire a random one
			//if not, finish.
			Transition t = null;
			if (!enabledTransitions.isEmpty()) {

				t = Lists.newArrayList(enabledTransitions)
						.get((int) Math.floor(Math.random() * enabledTransitions.size()));

				//if its not invisible, create the new time and the event
				if (!t.isInvisible()) {
					trace.add(createEvent(t.getLabel(), eventTime));
					long newTime = 0; //add a strictly positive time.
					do{
						newTime = Math.round(settings.getTaskDurationDistribution().nextDouble());
					} while (newTime <= 0);
					eventTime = eventTime + newTime;
				}

			} else
				//there is nothing else enabled, so return.
				return trace;

			//update markup
			PetrinetUtils.fireTransition(t, markings, petriNet);

		}
		return trace;
	}

}
