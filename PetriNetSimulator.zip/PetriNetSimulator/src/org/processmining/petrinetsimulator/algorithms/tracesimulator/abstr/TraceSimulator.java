package org.processmining.petrinetsimulator.algorithms.tracesimulator.abstr;


import org.deckfour.xes.model.XTrace;

public interface TraceSimulator {
	
	public XTrace simulateTrace(long startTime, int traceID);

}
