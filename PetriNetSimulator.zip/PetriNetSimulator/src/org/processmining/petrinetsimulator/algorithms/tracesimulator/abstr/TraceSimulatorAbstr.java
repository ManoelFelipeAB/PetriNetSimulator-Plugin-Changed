package org.processmining.petrinetsimulator.algorithms.tracesimulator.abstr;

import org.deckfour.xes.factory.XFactory;
import org.deckfour.xes.model.XAttributeMap;
import org.deckfour.xes.model.XEvent;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.petrinetsimulator.constants.LogConstants;
import org.processmining.petrinetsimulator.parameters.SimulationSettings;

public abstract class TraceSimulatorAbstr implements TraceSimulator {

	protected PluginContext context;
	protected XFactory factory;
	protected SimulationSettings settings;
	
	public TraceSimulatorAbstr(PluginContext context, XFactory factory, SimulationSettings settings){
		this.context = context;
		this.factory = factory;
		this.settings = settings;
	}
	
	protected XEvent createEvent(String name, long time) {

		XAttributeMap atts = factory.createAttributeMap();

		atts.put(LogConstants.EVENTID, factory.createAttributeLiteral(LogConstants.EVENTID, name, null));
		atts.put(LogConstants.TIMESTAMP, factory.createAttributeTimestamp(LogConstants.TIMESTAMP, time, null));
		atts.put(LogConstants.LIFECYCLE, factory.createAttributeLiteral(LogConstants.LIFECYCLE, "complete", null));

		return factory.createEvent(atts);
	}
}
