package org.processmining.petrinetsimulator.algorithms.tracesimulator.processtree;

/**
 * Simulator for process trees.
 * 
 * @author abolt
 *
 */
public class TraceSimulatorPT {

}
