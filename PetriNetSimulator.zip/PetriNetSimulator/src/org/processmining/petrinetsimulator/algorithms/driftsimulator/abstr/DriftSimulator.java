package org.processmining.petrinetsimulator.algorithms.driftsimulator.abstr;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;
import org.deckfour.xes.model.XLog;

public interface DriftSimulator<T> {

	public XLog simulateDrift(T model1, T model2);

	public List<Date> getDriftPoints();
	
	public List<Pair<Long, Double>> getTimePoints();
	
	public List<Pair<Long, Double>> getTracePoints();
}
