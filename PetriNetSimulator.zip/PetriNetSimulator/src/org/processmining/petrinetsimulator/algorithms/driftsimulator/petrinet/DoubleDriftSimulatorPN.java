package org.processmining.petrinetsimulator.algorithms.driftsimulator.petrinet;

import java.util.Date;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.deckfour.xes.factory.XFactory;
import org.deckfour.xes.model.XLog;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.petrinetsimulator.algorithms.driftsimulator.abstr.DriftSimulatorAbstr;
import org.processmining.petrinetsimulator.algorithms.tracesimulator.abstr.TraceSimulator;
import org.processmining.petrinetsimulator.algorithms.tracesimulator.petrinet.TraceSimulatorPN;
import org.processmining.petrinetsimulator.constants.SettingsConstants;
import org.processmining.petrinetsimulator.parameters.ConceptDriftSettings;
import org.processmining.petrinetsimulator.utils.StatisticsUtils;

import cern.jet.random.Uniform;
import cern.jet.random.engine.DRand;

public class DoubleDriftSimulatorPN extends DriftSimulatorAbstr<Petrinet> {

	public DoubleDriftSimulatorPN(PluginContext context, XFactory factory, ConceptDriftSettings settings) {
		super(context, factory, settings);

	}

	public XLog simulateDrift(Petrinet model1, Marking marking1, Petrinet model2, Marking marking2, Petrinet model3,
			Marking marking3) {

		TraceSimulator baseSim = new TraceSimulatorPN(context, model1, marking1, factory,
				settings.getCoreSimulationSettings());
		TraceSimulator drift1_Sim = new TraceSimulatorPN(context, model2, marking2, factory,
				settings.getCoreSimulationSettings());
		TraceSimulator drift2_Sim = new TraceSimulatorPN(context, model3, marking3, factory,
				settings.getCoreSimulationSettings());

		int traceID = 0;
		long currentTime = settings.getCoreSimulationSettings().getStartDate().getTime();

		DRand rand = new DRand(new Date(System.currentTimeMillis()));
		Uniform numberGenerator = new Uniform(rand);

		XLog log = factory.createLog();

		//simulate the stable time
		long stableFinalTime = currentTime + Math.round(settings.getDurationOfStablePeriod().nextDouble());

		/*
		 * first Stable Period
		 */
		while (currentTime < stableFinalTime) {

			log.add(baseSim.simulateTrace(currentTime, traceID));

			timePoints.add(new ImmutablePair<Long, Double>(currentTime, settings.getSamplingProbEvenPeriods()));
			tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, settings.getSamplingProbEvenPeriods()));

			traceID++;
			currentTime = currentTime
					+ Math.round(settings.getCoreSimulationSettings().getCaseArrivalDistribution().nextDouble());
		}

		/*
		 * First drift period (if not sudden)
		 */

		driftPoints.add(new Date(currentTime));//first trace with drift

		if (!settings.getDriftType().equals(SettingsConstants.SUDDEN)) {

			long driftFinalTime = stableFinalTime + Math.round(settings.getDurationOfDriftPeriod().nextDouble());
			long driftStartTime = stableFinalTime;

			if (settings.getDriftType().equals(SettingsConstants.MOMENTARY)) {
				//drift period is split in two, ascendant (more) and descendant (less). we assume equal splits.

				while (currentTime < driftFinalTime) {
					long midTime = driftStartTime + (driftFinalTime - driftStartTime) / 2;
					if (currentTime < midTime) {
						//ascendant function
						double newnumber = StatisticsUtils.getProbability(currentTime - driftStartTime,
								midTime - driftStartTime, settings.getSamplingProbEvenPeriods(),
								settings.getSamplingProbOddPeriods(), settings.getDurationOfDriftPeriod(),
								settings.getDriftTransitionFunction());
						if (newnumber > numberGenerator.nextDouble())
							log.add(baseSim.simulateTrace(currentTime, traceID));
						else
							log.add(drift1_Sim.simulateTrace(currentTime, traceID));
						timePoints.add(new ImmutablePair<Long, Double>(currentTime, newnumber));
						tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, newnumber));
					} else {
						//descendant function
						double newnumber = StatisticsUtils.getProbability(currentTime - midTime,
								driftFinalTime - midTime, settings.getSamplingProbOddPeriods(),
								settings.getSamplingProbEvenPeriods(), settings.getDurationOfDriftPeriod(),
								settings.getDriftTransitionFunction());
						if (newnumber > numberGenerator.nextDouble())
							log.add(baseSim.simulateTrace(currentTime, traceID));
						else
							log.add(drift1_Sim.simulateTrace(currentTime, traceID));
						timePoints.add(new ImmutablePair<Long, Double>(currentTime, newnumber));
						tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, newnumber));
					}
					traceID++;
					currentTime = currentTime + Math
							.round(settings.getCoreSimulationSettings().getCaseArrivalDistribution().nextDouble());

				}
				driftPoints.add(new Date(currentTime));//first trace without drift

			} else if (settings.getDriftType().equals(SettingsConstants.GRADUAL)) {

				while (currentTime < driftFinalTime) {

					double newnumber = StatisticsUtils.getProbability(currentTime - driftStartTime,
							driftFinalTime - driftStartTime, settings.getSamplingProbEvenPeriods(),
							settings.getSamplingProbOddPeriods(), settings.getDurationOfDriftPeriod(),
							settings.getDriftTransitionFunction());
					if (newnumber > numberGenerator.nextDouble())
						log.add(baseSim.simulateTrace(currentTime, traceID));
					else
						log.add(drift1_Sim.simulateTrace(currentTime, traceID));
					timePoints.add(new ImmutablePair<Long, Double>(currentTime, newnumber));
					tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, newnumber));

					traceID++;
					currentTime = currentTime + Math
							.round(settings.getCoreSimulationSettings().getCaseArrivalDistribution().nextDouble());
				}
				driftPoints.add(new Date(currentTime));//first trace without drift
			}
		}
		
		/*
		 * Second stable period
		 */
		stableFinalTime = currentTime + Math.round(settings.getDurationOfStablePeriod().nextDouble());
		
		while (currentTime < stableFinalTime) {

			log.add(drift1_Sim.simulateTrace(currentTime, traceID));
			timePoints.add(new ImmutablePair<Long, Double>(currentTime, settings.getSamplingProbOddPeriods()));
			tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, settings.getSamplingProbOddPeriods()));

			traceID++;
			currentTime = currentTime
					+ Math.round(settings.getCoreSimulationSettings().getCaseArrivalDistribution().nextDouble());
		}

		/*
		 * Second drift period (if not sudden)
		 */
		driftPoints.add(new Date(currentTime));//first trace with drift

		if (!settings.getDriftType().equals(SettingsConstants.SUDDEN)) {

			long driftFinalTime = stableFinalTime + Math.round(settings.getDurationOfDriftPeriod().nextDouble());
			long driftStartTime = stableFinalTime;

			if (settings.getDriftType().equals(SettingsConstants.MOMENTARY)) {
				//drift period is split in two, ascendant (more) and descendant (less). we assume equal splits.

				while (currentTime < driftFinalTime) {
					long midTime = driftStartTime + (driftFinalTime - driftStartTime) / 2;
					if (currentTime < midTime) {
						//ascendant function
						double newnumber = StatisticsUtils.getProbability(currentTime - driftStartTime,
								midTime - driftStartTime, settings.getSamplingProbOddPeriods(),
								settings.getSamplingProbEvenPeriods(), settings.getDurationOfDriftPeriod(),
								settings.getDriftTransitionFunction());
						if (newnumber > numberGenerator.nextDouble())
							log.add(drift1_Sim.simulateTrace(currentTime, traceID));
						else
							log.add(drift2_Sim.simulateTrace(currentTime, traceID));
						timePoints.add(new ImmutablePair<Long, Double>(currentTime, newnumber));
						tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, newnumber));
					} else {
						//descendant function
						double newnumber = StatisticsUtils.getProbability(currentTime - midTime,
								driftFinalTime - midTime, settings.getSamplingProbOddPeriods(),
								settings.getSamplingProbEvenPeriods(), settings.getDurationOfDriftPeriod(),
								settings.getDriftTransitionFunction());
						if (newnumber > numberGenerator.nextDouble())
							log.add(drift1_Sim.simulateTrace(currentTime, traceID));
						else
							log.add(drift2_Sim.simulateTrace(currentTime, traceID));
						timePoints.add(new ImmutablePair<Long, Double>(currentTime, newnumber));
						tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, newnumber));
					}
					traceID++;
					currentTime = currentTime + Math
							.round(settings.getCoreSimulationSettings().getCaseArrivalDistribution().nextDouble());

				}
				driftPoints.add(new Date(currentTime));//first trace without drift

			} else if (settings.getDriftType().equals(SettingsConstants.GRADUAL)) {

				while (currentTime < driftFinalTime) {

					double newnumber = StatisticsUtils.getProbability(currentTime - driftStartTime,
							driftFinalTime - driftStartTime, settings.getSamplingProbEvenPeriods(),
							settings.getSamplingProbOddPeriods(), settings.getDurationOfDriftPeriod(),
							settings.getDriftTransitionFunction());
					if (newnumber > numberGenerator.nextDouble())
						log.add(drift1_Sim.simulateTrace(currentTime, traceID));
					else
						log.add(drift2_Sim.simulateTrace(currentTime, traceID));
					timePoints.add(new ImmutablePair<Long, Double>(currentTime, newnumber));
					tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, newnumber));

					traceID++;
					currentTime = currentTime + Math
							.round(settings.getCoreSimulationSettings().getCaseArrivalDistribution().nextDouble());
				}
				driftPoints.add(new Date(currentTime));//first trace without drift
			}
		}
		
		/*
		 * Third stable period
		 */
		stableFinalTime = currentTime + Math.round(settings.getDurationOfStablePeriod().nextDouble());
		
		while (currentTime < stableFinalTime) {

			log.add(drift2_Sim.simulateTrace(currentTime, traceID));
			timePoints.add(new ImmutablePair<Long, Double>(currentTime, settings.getSamplingProbEvenPeriods()));
			tracePoints.add(
					new ImmutablePair<Long, Double>((long) traceID, settings.getSamplingProbEvenPeriods()));

			traceID++;
			currentTime = currentTime + Math
					.round(settings.getCoreSimulationSettings().getCaseArrivalDistribution().nextDouble());
		}

		return log;

	}

	public XLog simulateDrift(Petrinet model1, Petrinet model2) {
		// TODO Auto-generated method stub
		return null;
	}

}
