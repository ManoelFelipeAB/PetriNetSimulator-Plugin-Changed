package org.processmining.petrinetsimulator.algorithms.driftsimulator.abstr;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.tuple.Pair;
import org.deckfour.xes.factory.XFactory;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.petrinetsimulator.parameters.ConceptDriftSettings;

public abstract class DriftSimulatorAbstr<T> implements DriftSimulator<T>{

	protected PluginContext context;
	protected XFactory factory;
	protected ConceptDriftSettings settings;
	protected List<Date> driftPoints;
	protected List<Pair<Long, Double>> timePoints, tracePoints;
	
	public DriftSimulatorAbstr(PluginContext context, XFactory factory, ConceptDriftSettings settings){
		this.context = context;
		this.factory = factory;
		this.settings = settings;
		
		this.driftPoints = new ArrayList<Date>();
		timePoints = new ArrayList<Pair<Long, Double>>();
		tracePoints = new ArrayList<Pair<Long, Double>>();
	}
	
	public List<Date> getDriftPoints() {
		Collections.sort(driftPoints);
		return driftPoints;
	}
	
	public List<Pair<Long, Double>> getTimePoints(){
		return timePoints;
	}
	
	public List<Pair<Long, Double>> getTracePoints(){
		return tracePoints;
	}
}
