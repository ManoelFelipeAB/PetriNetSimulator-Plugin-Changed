package org.processmining.petrinetsimulator.algorithms.driftsimulator.processtree;

import java.util.Date;

import org.apache.commons.lang3.tuple.ImmutablePair;
import org.deckfour.xes.factory.XFactory;
import org.deckfour.xes.model.XLog;
import org.processmining.framework.plugin.PluginContext;
import org.processmining.petrinetsimulator.algorithms.driftsimulator.abstr.DriftSimulatorAbstr;
import org.processmining.petrinetsimulator.algorithms.tracesimulator.abstr.TraceSimulator;
import org.processmining.petrinetsimulator.algorithms.tracesimulator.processtree.TraceSimulatorNT;
import org.processmining.petrinetsimulator.constants.SettingsConstants;
import org.processmining.petrinetsimulator.parameters.ConceptDriftSettings;
import org.processmining.petrinetsimulator.utils.StatisticsUtils;
import org.processmining.ptandloggenerator.models.NewickTree;

import cern.jet.random.Uniform;
import cern.jet.random.engine.DRand;

public class DriftSimulatorNT extends DriftSimulatorAbstr<NewickTree> {

	public DriftSimulatorNT(PluginContext context, XFactory factory, ConceptDriftSettings settings) {
		super(context, factory, settings);		
	}

	public XLog simulateDrift(NewickTree model1, NewickTree model2) {

		TraceSimulator baseSim = new TraceSimulatorNT(context, model1, factory, settings.getCoreSimulationSettings());
		TraceSimulator driftSim = new TraceSimulatorNT(context, model2, factory, settings.getCoreSimulationSettings());

		//for every remaining drift point
		boolean isOdd = false;

		int traceID = 0;
		long currentTime = settings.getCoreSimulationSettings().getStartDate().getTime();

		DRand rand = new DRand(new Date(System.currentTimeMillis()));
		Uniform numberGenerator = new Uniform(rand);

		XLog log = factory.createLog();

		for (int i = 0; i <= settings.getNumberOfDrifts(); i++) {

			//simulate the stable time
			long stableFinalTime = currentTime + Math.round(settings.getDurationOfStablePeriod().nextDouble());

			while (currentTime < stableFinalTime) {
				if (!isOdd) {
					if (settings.getSamplingProbEvenPeriods() > numberGenerator.nextDouble())
						log.add(baseSim.simulateTrace(currentTime, traceID));
					else
						log.add(driftSim.simulateTrace(currentTime, traceID));
					timePoints.add(new ImmutablePair<Long, Double>(currentTime, settings.getSamplingProbEvenPeriods()));
					tracePoints.add(
							new ImmutablePair<Long, Double>((long) traceID, settings.getSamplingProbEvenPeriods()));
				} else {
					if (settings.getSamplingProbOddPeriods() > numberGenerator.nextDouble())
						log.add(baseSim.simulateTrace(currentTime, traceID));
					else
						log.add(driftSim.simulateTrace(currentTime, traceID));
					timePoints.add(new ImmutablePair<Long, Double>(currentTime, settings.getSamplingProbOddPeriods()));
					tracePoints
							.add(new ImmutablePair<Long, Double>((long) traceID, settings.getSamplingProbOddPeriods()));
				}
				traceID++;
				currentTime = currentTime
						+ Math.round(settings.getCoreSimulationSettings().getCaseArrivalDistribution().nextDouble());
			}

			// simulate unstable (drifting) time
			if (i != settings.getNumberOfDrifts()) {
				//do not add drift, end with a stable period.
				driftPoints.add(new Date(currentTime));//first trace with drift

				if (!settings.getDriftType().equals(SettingsConstants.SUDDEN)) {

					long driftFinalTime = stableFinalTime
							+ Math.round(settings.getDurationOfDriftPeriod().nextDouble());
					long driftStartTime = stableFinalTime;

					if (settings.getDriftType().equals(SettingsConstants.MOMENTARY)) {
						//drift period is split in two, ascendant (more) and descendant (less). we assume equal splits.

						while (currentTime < driftFinalTime) {
							long midTime = driftStartTime + (driftFinalTime - driftStartTime) / 2;
							if (currentTime < midTime) {
								//ascendant function
								double newnumber = StatisticsUtils.getProbability(currentTime - driftStartTime,
										midTime - driftStartTime, settings.getSamplingProbEvenPeriods(),
										settings.getSamplingProbOddPeriods(), settings.getDurationOfDriftPeriod(),
										settings.getDriftTransitionFunction());
								if (newnumber > numberGenerator.nextDouble())
									log.add(baseSim.simulateTrace(currentTime, traceID));
								else
									log.add(driftSim.simulateTrace(currentTime, traceID));
								timePoints.add(new ImmutablePair<Long, Double>(currentTime, newnumber));
								tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, newnumber));
							} else {
								//descendant function
								double newnumber = StatisticsUtils.getProbability(currentTime - midTime,
										driftFinalTime - midTime, settings.getSamplingProbOddPeriods(),
										settings.getSamplingProbEvenPeriods(), settings.getDurationOfDriftPeriod(),
										settings.getDriftTransitionFunction());
								if (newnumber > numberGenerator.nextDouble())
									log.add(baseSim.simulateTrace(currentTime, traceID));
								else
									log.add(driftSim.simulateTrace(currentTime, traceID));
								timePoints.add(new ImmutablePair<Long, Double>(currentTime, newnumber));
								tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, newnumber));
							}
							traceID++;
							currentTime = currentTime + Math.round(
									settings.getCoreSimulationSettings().getCaseArrivalDistribution().nextDouble());

						}
						driftPoints.add(new Date(currentTime));//first trace without drift

					} else if (settings.getDriftType().equals(SettingsConstants.GRADUAL)) {

						while (currentTime < driftFinalTime) {

							if (!isOdd) {
								double newnumber = StatisticsUtils.getProbability(currentTime - driftStartTime,
										driftFinalTime - driftStartTime, settings.getSamplingProbEvenPeriods(),
										settings.getSamplingProbOddPeriods(), settings.getDurationOfDriftPeriod(),
										settings.getDriftTransitionFunction());
								if (newnumber > numberGenerator.nextDouble())
									log.add(baseSim.simulateTrace(currentTime, traceID));
								else
									log.add(driftSim.simulateTrace(currentTime, traceID));
								timePoints.add(new ImmutablePair<Long, Double>(currentTime, newnumber));
								tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, newnumber));

							} else {
								double newnumber = StatisticsUtils.getProbability(currentTime - driftStartTime,
										driftFinalTime - driftStartTime, settings.getSamplingProbOddPeriods(),
										settings.getSamplingProbEvenPeriods(), settings.getDurationOfDriftPeriod(),
										settings.getDriftTransitionFunction());
								if (newnumber > numberGenerator.nextDouble())
									log.add(baseSim.simulateTrace(currentTime, traceID));
								else
									log.add(driftSim.simulateTrace(currentTime, traceID));
								timePoints.add(new ImmutablePair<Long, Double>(currentTime, newnumber));
								tracePoints.add(new ImmutablePair<Long, Double>((long) traceID, newnumber));
							}

							traceID++;
							currentTime = currentTime + Math.round(
									settings.getCoreSimulationSettings().getCaseArrivalDistribution().nextDouble());
						}
						driftPoints.add(new Date(currentTime));//first trace without drift
					}
				}
			}

			//from even to odd and viceversa, except in momentary drift where the even state happens always
			if (!settings.getDriftType().equals(SettingsConstants.MOMENTARY))
				isOdd = !isOdd;
		}
		return log;
	}

}
