package org.processmining.petrinetsimulator.help;

public class HelpText {

	public final static String SIMULATOR_TEXT = "Simluates an event log by replaying tokens into a petrinet. "
			+ "All the enabled transitions have the same probabilities of being triggered.";
	
	public final static String CONCEPT_DRIFT_TEXT = "Simluates an event log by sampling from the base and drift petrinets.";
}
